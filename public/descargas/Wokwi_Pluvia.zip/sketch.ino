// Simulacion Wokwi de la version de dos desagues.
// Motor y bomba se visualizan mediante LED; no hay simulacion hidraulica.
// Maqueta de dos desagües. Seleccionar ESP32 Dev Module (WROOM clásico).
#include <Arduino.h>
#include <LiquidCrystal.h>
#include <ESP32Servo.h>
#include <stdint.h>

namespace Cfg {
struct Sensor { uint8_t trig, echo; float fondoCm, minimoCm; };
// Montar a estas distancias o sustituirlas por las medidas reales con una regla.
// Para dos HC-SR04, poner en D1 el fondo medido y minimoCm = 2.
constexpr Sensor sensores[] = {{13, 34, 40.0f, 25.0f}, {14, 35, 14.0f, 2.0f}};
constexpr float profundidadCm = 10;
constexpr uint8_t motor = 27, bomba = 17, servo = 23, ldr = 32;
constexpr uint8_t verde = 2, amarillo = 5, rojo = 15;
constexpr uint8_t rs = 21, enable = 22, d4 = 25, d5 = 26, d6 = 33, d7 = 4;
constexpr uint8_t botonBoot = 0;  // Pulsar solo DESPUÉS del arranque.
constexpr int cerrado = 0, abierto = 90;
constexpr int adcDia = 1400, adcOscuro = 2000;
constexpr uint32_t viajeServoMs = 400, motorMs = 4000, confirmarMs = 1000;
constexpr uint32_t dosisMs = 5000, capacidadMs = 20000;
// Medir mL/s que entran por el filtro y dividir por mL/s que salen por la bomba.
constexpr float relacionCaudal = 1.0f;
static_assert(relacionCaudal > 0 && capacidadMs >= dosisMs, "Revisar tiempos y caudales");
}

#include <math.h>

struct Control {
  bool confirmado = false, compuerta = false, motor = false, bomba = false;
  float disponibleMs = 0;
  uint32_t anterior = 0, movimiento = 0, comienzoMotor = 0, comienzoDosis = 0;
  uint32_t duracionDosis = 0, desdeAlto = 0, desdeBajo = 0;
  bool contandoAlto = false, contandoBajo = false, armado = true, lleno = false;

  void confirmarVacio(uint32_t ahora) {
    // Una confirmación por arranque. No borra un saldo ya calculado.
    if (!confirmado) { confirmado = true; anterior = ahora; }
  }

  void paso(uint32_t ahora, float d1, float d2, bool luz) {
    const uint32_t dt = ahora - anterior;
    const uint32_t edadServo = ahora - movimiento;
    anterior = ahora;
    // Sumar entrada y restar bombeo del mismo intervalo antes de limitar el saldo.
    uint32_t entradaMs = 0;
    if (compuerta && edadServo > Cfg::viajeServoMs) {
      const uint32_t estable = edadServo - Cfg::viajeServoMs;
      entradaMs = dt < estable ? dt : estable;
    }
    disponibleMs = fminf(Cfg::capacidadMs, fmaxf(0.0f,
        disponibleMs + entradaMs * Cfg::relacionCaudal - (bomba ? dt : 0)));
    const bool validos = isfinite(d1) && isfinite(d2);
    bool abrir = compuerta;
    if (disponibleMs >= Cfg::capacidadMs) lleno = true;
    if (disponibleMs <= Cfg::capacidadMs - 1000) lleno = false;
    if (!confirmado || !validos || lleno || (d1 < 40 && d2 < 40)) abrir = false;
    else if (d1 >= 50 || d2 >= 50) abrir = true;
    if (abrir != compuerta) { compuerta = abrir; movimiento = ahora; }
    const bool servoQuieto = uint32_t(ahora - movimiento) >= Cfg::viajeServoMs;

    if (isfinite(d1) && d1 < 40) {
      if (!contandoBajo) desdeBajo = ahora;
      contandoBajo = true;
      if (ahora - desdeBajo >= Cfg::confirmarMs) armado = true;
    } else contandoBajo = false;
    if (isfinite(d1) && d1 >= 80) {
      if (!contandoAlto) desdeAlto = ahora;
      contandoAlto = true;
    } else contandoAlto = false;

    if (motor && (!isfinite(d1) || d1 < 40 || !servoQuieto ||
                   ahora - comienzoMotor >= Cfg::motorMs)) motor = false;
    if (confirmado && armado && contandoAlto && servoQuieto &&
        ahora - desdeAlto >= Cfg::confirmarMs) {
      motor = true; armado = false; comienzoMotor = ahora;
    }

    const bool puedeRegar = confirmado && luz && servoQuieto && !motor && disponibleMs >= 1;
    if (!puedeRegar || ahora - comienzoDosis >= duracionDosis) bomba = false;
    if (puedeRegar && !bomba) {
      comienzoDosis = ahora;
      duracionDosis = uint32_t(fminf(Cfg::dosisMs, disponibleMs));
      bomba = true;
    }
  }
};

#if !defined(CONFIG_IDF_TARGET_ESP32)
#error Este montaje requiere un ESP32 clasico.
#endif
LiquidCrystal lcd(Cfg::rs, Cfg::enable, Cfg::d4, Cfg::d5, Cfg::d6, Cfg::d7);
Servo puerta;
Control control;
float porcentaje[2] = {NAN, NAN};
uint8_t lecturasBuenas[2] = {};
uint32_t medidaMs[2] = {};
int luzAdc = 0;
bool dia = false;

void medir(unsigned i);
void linea(int fila, const char *mensaje);
void confirmar(uint32_t ahora);

void medir(unsigned i) {
  const auto &s = Cfg::sensores[i];
  float nivel = NAN;
  if (s.fondoCm - Cfg::profundidadCm >= s.minimoCm) {
    digitalWrite(s.trig, HIGH);
    delayMicroseconds(20);
    digitalWrite(s.trig, LOW);
    const unsigned long eco = pulseIn(s.echo, HIGH, (s.fondoCm + 5) * 60 + 1000);
    const float distancia = eco / 58.0f;
    if (eco && distancia >= s.minimoCm && distancia <= s.fondoCm + 1) {
      nivel = constrain(100.f * (s.fondoCm - distancia) / Cfg::profundidadCm, 0.f, 100.f);
    }
  }
  if (!isfinite(nivel)) lecturasBuenas[i] = 0;
  else if (lecturasBuenas[i] < 2) ++lecturasBuenas[i];
  porcentaje[i] = lecturasBuenas[i] == 2 ? nivel : NAN;
  medidaMs[i] = millis();
}

void linea(int fila, const char *mensaje) {
  char buf[17];
  snprintf(buf, sizeof(buf), "%-16.16s", mensaje);
  lcd.setCursor(0, fila); lcd.print(buf);
}

void confirmar(uint32_t ahora) {
  if (control.confirmado) return;
  // Una V mayúscula en el monitor serie, o mantener BOOT un segundo.
  static bool habilitado = false, pulsando = false;
  static uint32_t inicio = 0;
  if (digitalRead(Cfg::botonBoot) == HIGH) { habilitado = true; pulsando = false; }
  else if (habilitado) {
    if (!pulsando) { pulsando = true; inicio = ahora; }
    if (ahora - inicio >= 1000) control.confirmarVacio(ahora);
  }
  if (Serial.available() && Serial.read() == 'V') control.confirmarVacio(ahora);
}

void setup() {
  Serial.begin(115200);
  pinMode(Cfg::motor, OUTPUT); digitalWrite(Cfg::motor, LOW);
  pinMode(Cfg::bomba, OUTPUT); digitalWrite(Cfg::bomba, LOW);
  for (const auto &s : Cfg::sensores) {
    pinMode(s.trig, OUTPUT); digitalWrite(s.trig, LOW); pinMode(s.echo, INPUT);
  }
  for (auto pin : {Cfg::verde, Cfg::amarillo, Cfg::rojo}) pinMode(pin, OUTPUT);
  pinMode(Cfg::botonBoot, INPUT_PULLUP);
  analogReadResolution(12);
  lcd.begin(16, 2);
  linea(0, "Deposito vacio?"); linea(1, "BOOT 1s o V USB");
  puerta.setPeriodHertz(50); puerta.attach(Cfg::servo, 500, 2400); puerta.write(Cfg::cerrado);
  Serial.println("PLUVIA DOS | Confirma deposito vacio con V o BOOT 1s tras el arranque.");
}

void loop() {
  static uint32_t ultimoEco = 0, ultimaVista = 0;
  static unsigned turno = 0;
  if (millis() - ultimoEco >= 100) {
    ultimoEco = millis(); medir(turno); turno ^= 1;
    luzAdc = analogRead(Cfg::ldr);
    if (luzAdc <= Cfg::adcDia) dia = true;
    if (luzAdc >= Cfg::adcOscuro) dia = false;
  }
  uint32_t ahora = millis();
  confirmar(ahora);
  for (unsigned i = 0; i < 2; ++i)
    if (ahora - medidaMs[i] > 800) porcentaje[i] = NAN;
  const bool abiertaAntes = control.compuerta;
  control.paso(ahora, porcentaje[0], porcentaje[1], dia);
  // Apagar cargas antes de mover el servo o arrancar el otro canal.
  if (!control.bomba) digitalWrite(Cfg::bomba, LOW);
  if (!control.motor) digitalWrite(Cfg::motor, LOW);
  if (abiertaAntes != control.compuerta) puerta.write(control.compuerta ? Cfg::abierto : Cfg::cerrado);
  if (control.motor) digitalWrite(Cfg::motor, HIGH);
  if (control.bomba) digitalWrite(Cfg::bomba, HIGH);
  bool fallo = !isfinite(porcentaje[0]) || !isfinite(porcentaje[1]);
  float maximo = fmaxf(porcentaje[0], porcentaje[1]);
  digitalWrite(Cfg::rojo, (fallo || maximo >= 80) ? LOW : HIGH);
  digitalWrite(Cfg::amarillo, (!fallo && maximo >= 50 && maximo < 80) ? LOW : HIGH);
  digitalWrite(Cfg::verde, (!fallo && maximo < 50) ? HIGH : LOW);
  if (ahora - ultimaVista >= 400) {
    ultimaVista = ahora;
    char nivel[2][6], fila[30];
    for (unsigned i = 0; i < 2; ++i) {
      if (isfinite(porcentaje[i])) snprintf(nivel[i], sizeof(nivel[i]), "%.0f%%", porcentaje[i]);
      else strcpy(nivel[i], "ERR");
    }
    snprintf(fila, sizeof(fila), "D1:%s D2:%s", nivel[0], nivel[1]); linea(0, fila);
    if (!control.confirmado) linea(1, "Vacio? BOOT 1s");
    else {
      snprintf(fila, sizeof(fila), "Est:%4.1fs %s", control.disponibleMs/1000.f,
               control.motor ? "MOTOR" : control.bomba ? "RIEGO" : control.compuerta ? "FILTRO" : "ESPERA");
      linea(1, fila);
    }
    Serial.printf("D1=%s D2=%s vacio_confirmado=%d saldo_est_s=%.2f luz=%d adc=%d servo=%d motor=%d bomba=%d\n",
        nivel[0], nivel[1], control.confirmado, control.disponibleMs/1000.f, dia, luzAdc,
        control.compuerta ? Cfg::abierto : Cfg::cerrado, control.motor, control.bomba);
  }
  delay(1);
}
